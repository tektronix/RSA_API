README-RSA API V3.11 Apps and Utilities.txt
2017-09-14

Windows demo applications and utilities for use with the RSA API supporting RSA306/RSA306B/RSA500A/RSA600A devices
The RSA API version must be 3.11.0001 or later.

Folder content:
    Apps/x64: 64-bit Windows executables
    Apps/x86: 32-bit Windows executables
    Bats:  Batch files with example demo app usage
    Docs:  Documentation file(s)


